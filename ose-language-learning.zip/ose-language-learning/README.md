# OSE｜重構外語學習

將《重構外語學習：整合認知科學、第二語言習得研究與學習設計的實用指南》轉為適合電腦、平板與手機閱讀的網站。

網站：https://language-learning-guide.expert-hawk-9289.chatgpt.site

## 內容與功能

- 七個文章分頁，保留原文、表格、圖片與資源連結。
- 可水平與垂直收合的目錄。
- 從中心向外展開的藍色點按動畫。
- OSE 字母交疊字標，按下切換深色與淺色模式。
- Docs 藍、深海藍、晴空藍三組配色，設定儲存於讀者的瀏覽器。
- 匿名累積到訪統計，同一分頁重整不重複計數。

## 建置

需要 Node.js 22 或更新版本。

```bash
npm ci
npm run build
```

建置結果為 `dist/server/index.js`，它是一個具有 `fetch` 方法的 Cloudflare Worker。網站 HTML、CSS、JavaScript 與圖片會內嵌在建置結果中。

## 檔案結構

| 位置 | 用途 |
| --- | --- |
| `dist/index.html` | 文章與介面 |
| `dist/app.js` | 導覽、動畫、主題與到訪統計互動 |
| `dist/style.css`、`dist/theme.css` | 響應式版面與配色 |
| `dist/assets/` | 文章原圖 |
| `worker/index.js` | 網站與匿名統計 API |
| `scripts/build-worker.mjs` | Worker 建置程式 |
| `db/schema.ts`、`drizzle/` | 到訪統計資料庫結構與遷移 |
| `.openai/hosting.json` | 現有 Sites 網站與資料庫綁定設定 |

## 到訪統計與部署

現有網站部署於 Sites，使用 Cloudflare D1 的 `DB` 綁定。部署前需要套用 `drizzle/` 內的資料庫遷移。

統計只儲存隨機的分頁到訪識別碼與日期，不儲存姓名、Email 或 IP。累積值表示到訪次數，不代表不重複訪客人數；功能啟用前的到訪不回補。

本儲存庫保存網站原始碼、圖片與資料庫結構。實際累積到訪資料仍留在現有 Sites 資料庫，不包含於 GitHub。

GitHub 僅保存程式碼；單用 GitHub Pages 無法執行這個 Worker 或 D1 到訪統計。

## 內容更新

網站內容依 Google Docs 手動同步，原始文件不會因網站編輯而被修改。發布中的文件副本、密鑰、登入資訊、`node_modules` 與產生的 Worker 不納入版本管理。
