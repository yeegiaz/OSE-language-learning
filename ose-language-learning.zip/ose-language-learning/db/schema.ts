import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const visits = sqliteTable('visits', {
  token: text('token').primaryKey(),
  day: text('day').notNull(),
});
