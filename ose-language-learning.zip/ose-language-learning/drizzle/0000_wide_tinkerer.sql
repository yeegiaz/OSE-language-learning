CREATE TABLE `visits` (
	`token` text PRIMARY KEY NOT NULL,
	`day` text NOT NULL
);
