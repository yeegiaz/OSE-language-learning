import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.png':'image/png','.jpg':'image/jpeg'};
const files={};
const html=await readFile('dist/index.html','utf8');
const assetNames=[...new Set([...html.matchAll(/src="(assets\/[^"?]+)(?:\?[^\"]*)?"/g)].map(match=>match[1]))];
for(const name of ['index.html','style.css','theme.css','app.js',...assetNames]){
 const ext=name.slice(name.lastIndexOf('.'));const binary=name.startsWith('assets/');
 const bytes=await readFile('dist/'+name);files['/'+name]={type:types[ext]||'application/octet-stream',binary,data:binary?bytes.toString('base64'):bytes.toString('utf8')};
}
await mkdir('dist/server',{recursive:true});
await writeFile('dist/server/index.js','const FILES='+JSON.stringify(files)+';\n'+await readFile('worker/index.js','utf8'));
console.log('Built Worker with '+Object.keys(files).length+' assets and the anonymous visit endpoint.');
