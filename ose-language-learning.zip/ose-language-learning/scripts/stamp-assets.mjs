import {readFile,writeFile} from 'node:fs/promises';
const filename='dist/index.html';
const html=await readFile(filename,'utf8');
await writeFile(filename,html.replace(/src="(assets\/[^"?]+)(?:\?v=\d+)?"/g,'src="$1?v=3"'));
