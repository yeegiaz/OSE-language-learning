function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: {'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'} });
}
async function visitCount(request, env) {
  if (!env.DB) return json({error:'統計暫無法取得'},503);
  try {
    if (request.method === 'POST') {
      if (request.headers.get('origin') !== new URL(request.url).origin) return json({error:'Invalid origin'},403);
      if (!request.headers.get('content-type')?.startsWith('application/json')) return json({error:'Invalid content type'},415);
      if (Number(request.headers.get('content-length') || 0) > 256) return json({error:'Invalid payload'},413);
      const body = await request.text();
      if (body.length > 256) return json({error:'Invalid payload'},413);
      const {token} = JSON.parse(body);
      if (typeof token !== 'string' || !/^[0-9a-f-]{36}$/.test(token)) return json({error:'Invalid token'},400);
      const day = new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Taipei'}).format(new Date());
      const results = await env.DB.batch([
        env.DB.prepare('INSERT INTO visits (token, day) VALUES (?, ?) ON CONFLICT(token) DO NOTHING').bind(token, day),
        env.DB.prepare('SELECT COUNT(*) AS total FROM visits'),
      ]);
      return json({total:Number(results[1].results[0].total),since:'2026-10-01'});
    }
    if (request.method !== 'GET') return json({error:'Method not allowed'},405);
    const row = await env.DB.prepare('SELECT COUNT(*) AS total FROM visits').first();
    return json({total:Number(row.total),since:'2026-10-01'});
  } catch { return json({error:'統計暫無法取得'},503); }
}
export default {
  async fetch(request, env) {
    const path = new URL(request.url).pathname;
    if (path === '/api/visits') return visitCount(request, env);
    if (!['GET','HEAD'].includes(request.method)) return new Response('Method not allowed',{status:405});
    const file = FILES[path === '/' ? '/index.html' : path];
    if (!file) return new Response('Not found',{status:404});
    const headers={'content-type':file.type,'cache-control':path.startsWith('/assets/')?'public, max-age=86400':'no-cache','x-content-type-options':'nosniff','referrer-policy':'strict-origin-when-cross-origin'};
    const bytes=file.binary?Uint8Array.from(atob(file.data),c=>c.charCodeAt(0)):file.data;
    return new Response(request.method==='HEAD'?null:bytes,{headers});
  }
};
